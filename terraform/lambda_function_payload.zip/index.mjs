import { S3Client, ListObjectsV2Command, GetObjectCommand, PutObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";

const s3Client = new S3Client({});
const BUCKET_NAME = process.env.BUCKET_NAME;

export const handler = async (event) => {
    const { routeKey, pathParameters, body } = event;
    const vaultName = pathParameters?.name;

    try {
        if (routeKey === "GET /vaults") {
            const listCommand = new ListObjectsV2Command({ Bucket: BUCKET_NAME });
            const response = await s3Client.send(listCommand);
            const vaults = response.Contents?.map(obj => obj.Key) || [];
            return {
                statusCode: 200,
                body: JSON.stringify({ vaults }),
            };
        }

        if (routeKey === "GET /vaults/{name}") {
            const getCommand = new GetObjectCommand({ Bucket: BUCKET_NAME, Key: vaultName });
            const response = await s3Client.send(getCommand);
            const streamToBuffer = (stream) =>
                new Promise((resolve, reject) => {
                    const chunks = [];
                    stream.on("data", (chunk) => chunks.push(chunk));
                    stream.on("error", reject);
                    stream.on("end", () => resolve(Buffer.concat(chunks)));
                });
            const buffer = await streamToBuffer(response.Body);
            return {
                statusCode: 200,
                body: buffer.toString("base64"),
                isBase64Encoded: true,
                headers: { "Content-Type": "application/octet-stream" }
            };
        }

        if (routeKey === "PUT /vaults/{name}") {
            const putCommand = new PutObjectCommand({
                Bucket: BUCKET_NAME,
                Key: vaultName,
                Body: Buffer.from(body, event.isBase64Encoded ? "base64" : "utf8")
            });
            await s3Client.send(putCommand);
            return {
                statusCode: 200,
                body: JSON.stringify({ message: "Vault saved successfully" }),
            };
        }

        if (routeKey === "DELETE /vaults/{name}") {
            const deleteCommand = new DeleteObjectCommand({ Bucket: BUCKET_NAME, Key: vaultName });
            await s3Client.send(deleteCommand);
            return {
                statusCode: 200,
                body: JSON.stringify({ message: "Vault deleted successfully" }),
            };
        }

        return {
            statusCode: 404,
            body: JSON.stringify({ message: "Not Found" }),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
        };
    }
};
